﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadSerialForOdoo
{
    public class Bascula
    {
        public string id { get; set; }
        public string peso_entrada { get; set; }
        public string peso_salida { get; set; }
        public string peso_neto { get; set; }
    }
}
