﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Threading.Tasks;

namespace ReadSerialForOdoo
{
    class Program
    {
        public static string serial_data;
        static void Main(string[] args)
        {
            SerialPort serialPort = new SerialPort("COM3");
           
            try
            {
                List<string> puertosDisponibles = new List<string>();
                foreach (string puertos in SerialPort.GetPortNames())
                {
                    puertosDisponibles.Add(puertos);
                }
                if (puertosDisponibles.Count > 0)
                {
                    serialPort.BaudRate = 9600;
                    serialPort.DataBits = 8;
                    serialPort.Parity = Parity.None;
                    serialPort.RtsEnable = true;
                    serialPort.StopBits = StopBits.One;
                    serialPort.Handshake = Handshake.None;
                    serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                    serialPort.Open();
                }
                else
                {
                    Console.WriteLine("No hay puertos disponibles.");
                    Console.Read();
                }

                 if (serialPort.IsOpen)
                {
                    WebServer ws = new WebServer(SendResponse, "http://+:8081/");
                    ws.Run();
                    Console.WriteLine("Servidor corriendo, presione una tecla para parar...");
                    Console.ReadKey();
                    ws.Stop();                   
                }
                else
                {
                    Console.WriteLine("No se pudo conectar.");
                    Console.Read();
                    serialPort.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocurrió un error: " + ex);
                Console.Read();
                serialPort.Close();
                throw;
            }

        }

        private static void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            Thread.Sleep(1500);
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();


            if (indata.Length > 0)
            {
                try
                {
                    char delimiter = '\n';
                    string[] substrings = indata.Split(delimiter);
                    //if (substrings.Count<string>() == 28)
                    if (substrings.Count<string>() == 14)
                    {

                        Console.WriteLine(substrings);
                        foreach (var substring in substrings)
                        {
                            if (substring.Length > 1)
                            {
                                Console.WriteLine(substring);

                             }
                      }
                        char delimeter2 = ':';
                        string[] id;
                        string peso_entrada;
                        string peso_salida;
                        string peso_neto;

                        peso_entrada = substrings[5];
                        peso_salida = "0";
                        peso_neto = "0";
                        id = substrings[6].Split(delimeter2);
                        if (substrings.Count<string>() == 28)
                        {
                            peso_entrada = substrings[17];
                            peso_salida = substrings[18];
                            peso_neto = substrings[19];
                            id = substrings[20].Split(delimeter2);
                        }
                       

                        Bascula bascula = new Bascula { peso_entrada = String.Join("", peso_entrada.Where(char.IsDigit)), peso_salida = String.Join("", peso_salida.Where(char.IsDigit)), peso_neto = String.Join("", peso_neto.Where(char.IsDigit)), id = String.Join("", id[1].Where(char.IsLetterOrDigit)) };
                        var jsSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                        string jsonstring = jsSerializer.Serialize(bascula);
                        Console.WriteLine("<------------------------------------------------------------------------------------------------>");
                        //Console.WriteLine(jsonstring);
                        serial_data = jsonstring;
                    }
                    if (substrings.Count<string>() == 28)
                    {

                        Console.WriteLine(substrings);
                        foreach (var substring in substrings)
                        {
                            if (substring.Length > 1)
                            {
                                Console.WriteLine(substring);

                            }
                        }
                        char delimeter2 = ':';
                        string[] id;
                        string peso_entrada;
                        string peso_salida;
                        string peso_neto;

                        
                        peso_entrada = substrings[17];
                        peso_salida = substrings[18];
                        peso_neto = substrings[19];
                        id = substrings[20].Split(delimeter2);
                        


                        Bascula bascula = new Bascula { peso_entrada = String.Join("", peso_entrada.Where(char.IsDigit)), peso_salida = String.Join("", peso_salida.Where(char.IsDigit)), peso_neto = String.Join("", peso_neto.Where(char.IsDigit)), id = String.Join("", id[1].Where(char.IsLetterOrDigit)) };
                        var jsSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                        string jsonstring = jsSerializer.Serialize(bascula);
                        Console.WriteLine("<------------------------------------------------------------------------------------------------>");
                        //Console.WriteLine(jsonstring);
                        serial_data = jsonstring;
                    }
                    //else
                    //{
                    //    Console.WriteLine("ENTRADA, ESPERANDO SALIDA");
                    //    Console.WriteLine("peso en else: " + substrings[5]);
                    //    Console.WriteLine("placas: en else " + substrings[6]);
                    //    //peso = substrings[5];
                    //    //placas = substrings[6].Split(delimeter2);
                    //}



                    //System.IO.File.WriteAllText(@"C:\Users\Semillas\Desktop\bascula.txt", jsonstring);
                }
                catch (Exception err)
                {
                    Console.WriteLine(err.Message);
                }
            }
        }

        public static string SendResponse(HttpListenerRequest request)
        {
            return serial_data;
            //return string.Format(serial_data);
        }

    }
}
